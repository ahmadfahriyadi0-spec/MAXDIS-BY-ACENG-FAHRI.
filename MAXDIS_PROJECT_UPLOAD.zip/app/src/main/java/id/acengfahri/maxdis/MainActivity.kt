package id.acengfahri.maxdis

import android.app.*
import android.os.*
import android.content.*
import android.graphics.Color
import android.media.MediaPlayer
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.*
import java.util.Locale

class MainActivity : Activity() {
    private var count = 10
    private var remaining = 60
    private var running = false
    private var handler = Handler(Looper.getMainLooper())
    private var player: MediaPlayer? = null
    private lateinit var timerText: TextView
    private lateinit var pluText: EditText
    private lateinit var statusText: TextView
    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            remaining--
            timerText.text = format(remaining)
            if (remaining <= 0) {
                running = false
                statusText.text = "WAKTU SELESAI"
                playAlarm()
            } else handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(10, 18, 42)
        window.navigationBarColor = Color.rgb(10, 18, 42)
        buildUi()
    }

    private fun buildUi() {
        val base = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(Color.rgb(8, 15, 35))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        val brand = TextView(this).apply {
            text = "MAXDIS\nBY ACENG FAHRI"
            textSize = 25f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(8, 18, 8, 24); typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        content.addView(brand)
        content.addView(label("PENGHITUNG WAKTU PLU"))
        pluText = EditText(this).apply {
            hint = "Masukkan jumlah PLU"; setText("10"); textSize = 22f
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
            inputType = 2; gravity = Gravity.CENTER
            setPadding(12, 14, 12, 14)
            setBackgroundColor(Color.rgb(24, 39, 72))
        }
        content.addView(pluText, LinearLayout.LayoutParams(-1, -2))
        val calc = button("HITUNG DURASI") { calculate(false) }
        content.addView(calc)
        timerText = TextView(this).apply {
            text = "01:00"; textSize = 54f; gravity = Gravity.CENTER
            setTextColor(Color.rgb(65, 207, 255)); setPadding(8, 28, 8, 8)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        content.addView(timerText)
        statusText = label("1 PLU = 6 DETIK")
        statusText.gravity = Gravity.CENTER
        content.addView(statusText)
        content.addView(button("MULAI") {
            if (!running) { calculate(true); running = true; statusText.text = "TIMER BERJALAN"; handler.postDelayed(tick, 1000) }
        })
        content.addView(button("STOP") {
            running = false; handler.removeCallbacks(tick); statusText.text = "TIMER DIHENTIKAN"
        })
        content.addView(button("RESET") {
            running = false; handler.removeCallbacks(tick); calculate(false); statusText.text = "1 PLU = 6 DETIK"
        })
        content.addView(label("PENGATURAN ALARM"))
        val volume = Spinner(this)
        volume.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("Normal", "Mid", "High"))
        content.addView(volume)
        content.addView(button("PREVIEW NADA") { playAlarm() })
        content.addView(button("POPUP / FLOATING") { showPopup() })
        content.addView(button("DOWNLOAD / RIWAYAT") {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://")))
        })
        content.addView(label("MAXDIS BY ACENG FAHRI • VERSI 1.0"))
        base.addView(scroll)
        setContentView(base)
    }

    private fun calculate(update: Boolean) {
        val n = pluText.text.toString().toIntOrNull()?.coerceIn(1, 100000) ?: 1
        count = n; remaining = n * 6
        timerText.text = format(remaining)
        if (update) statusText.text = "TOTAL $n PLU"
    }
    private fun format(s: Int): String = String.format(Locale.US, "%02d:%02d", s / 60, s % 60)
    private fun label(s: String) = TextView(this).apply {
        text = s; textSize = 14f; setTextColor(Color.rgb(205, 220, 245))
        setPadding(4, 18, 4, 10)
    }
    private fun button(s: String, action: () -> Unit) = Button(this).apply {
        text = s; textSize = 15f; setTextColor(Color.WHITE)
        setBackgroundColor(Color.rgb(28, 104, 190))
        setOnClickListener { action() }
        val p = LinearLayout.LayoutParams(-1, -2); p.setMargins(0, 7, 0, 7)
        layoutParams = p
    }
    private fun playAlarm() {
        try {
            val uri = android.provider.Settings.System.DEFAULT_ALARM_ALERT_URI
            player?.release()
            player = MediaPlayer.create(this, uri)
            player?.start()
        } catch (_: Exception) {
            Toast.makeText(this, "Alarm selesai", Toast.LENGTH_SHORT).show()
        }
    }
    private fun showPopup() {
        if (!android.provider.Settings.canDrawOverlays(this)) {
            val i = Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivity(i)
            Toast.makeText(this, "Izinkan tampil di atas aplikasi lain, lalu tekan POPUP lagi", Toast.LENGTH_LONG).show()
            return
        }
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val tv = TextView(this).apply {
            text = "MAXDIS  •  ${format(remaining)}   ✕"
            textSize = 16f; setTextColor(Color.WHITE); setPadding(24, 18, 24, 18)
            setBackgroundColor(Color.rgb(20, 65, 125))
            setOnClickListener { try { wm.removeView(this) } catch (_: Exception) {} }
        }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(-2, -2, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, android.graphics.PixelFormat.TRANSLUCENT)
        params.gravity = Gravity.TOP or Gravity.END; params.x = 20; params.y = 120
        try { wm.addView(tv, params) } catch (_: Exception) { Toast.makeText(this, "Popup tidak dapat ditampilkan", Toast.LENGTH_SHORT).show() }
    }
    override fun onDestroy() {
        running = false; handler.removeCallbacks(tick); player?.release()
        super.onDestroy()
    }
}
